package group6.learnlock.ui.archive

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import group6.learnlock.repository.AssignmentRepository
import group6.learnlock.room.AssignmentDAO

class ArchiveViewModel: ViewModel() {


}