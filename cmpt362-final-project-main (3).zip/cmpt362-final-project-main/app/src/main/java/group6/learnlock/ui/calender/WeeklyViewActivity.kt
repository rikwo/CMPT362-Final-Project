package group6.learnlock.ui.calender

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import group6.learnlock.R

class WeeklyViewActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weekly_view)
    }
}